export type SignInDto = { email: string; password: string };
