export type LanguageContextType = {
  language: string;
  changeLanguage: (language: string) => void;
};
